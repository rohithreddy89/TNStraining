package com.example.placement.repositary;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.placement.entity.Student;

public interface StudentRepositary extends JpaRepository<Student, Long>{

}
