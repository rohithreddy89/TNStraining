package com.example.placement.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.placement.entity.Student;
import com.example.placement.repositary.StudentRepositary;

@Service
public class StudentService {

	@Autowired
	public StudentRepositary studentrepo;
	
	//insertion
	public Student addStudent(Student student) {
		
		return studentrepo.save(student);
		    
	}
	
	//traversal
	public List<Student> getStudent() {
		return studentrepo.findAll();
	}
	
	//deletion
	public void deleteStudent(Long id) {
		studentrepo.deleteById(id);
	}
	
	//update
	public Student updateStudent(Long id, Student student) {
		Optional<Student> existing = studentrepo.findById(id);
		if(existing.isPresent()) {
			Student s = existing.get();
			s.setName(student.getName());
			s.setRoll(student.getRoll());
			s.setQualification(student.getQualification());
			s.setCourse(student.getCourse());
			s.setYear(student.getYear());
			s.setHallTicketNo(student.getHallTicketNo());
			return studentrepo.save(s);
		}
		return null;
	}
}